import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';

// In development, start the Mock Service Worker so the app can run
// end-to-end against a mocked /api/events endpoint without a real backend.
async function enableMocking() {
  if (process.env.NODE_ENV !== 'development') {
    return;
  }
  const { worker } = await import('./mocks/browser');
  return worker.start({ onUnhandledRequest: 'bypass' });
}

const root = ReactDOM.createRoot(document.getElementById('root'));

enableMocking().finally(() => {
  root.render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
});
