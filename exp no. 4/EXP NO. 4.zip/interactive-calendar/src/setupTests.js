// jest-dom adds custom jest matchers for asserting on DOM nodes,
// e.g. expect(element).toBeInTheDocument()
import '@testing-library/jest-dom';
import { server } from './mocks/server';

// Start the mocked API before all tests, reset any per-test request
// handler overrides after each test, and clean up once everything's done.
beforeAll(() => server.listen({ onUnhandledRequest: 'error' }));
afterEach(() => server.resetHandlers());
afterAll(() => server.close());
