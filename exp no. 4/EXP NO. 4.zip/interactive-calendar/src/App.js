import React, { useState, useEffect, useCallback, useMemo } from 'react';
import Calendar from './components/Calendar';
import { getWeekDates } from './utils/dateUtils';

function App() {
  const [events, setEvents] = useState([]);
  const [status, setStatus] = useState('loading');

  // Computed once - the reference week never changes for the life of the app.
  const weekDates = useMemo(() => getWeekDates(new Date()), []);

  useEffect(() => {
    let cancelled = false;

    fetch('/api/events')
      .then((res) => res.json())
      .then((data) => {
        if (!cancelled) {
          setEvents(data);
          setStatus('ready');
        }
      })
      .catch(() => {
        if (!cancelled) setStatus('error');
      });

    return () => {
      cancelled = true;
    };
  }, []);

  // Passed down to Calendar/TimeSlot as a stable reference so memoized
  // children don't re-render just because App re-rendered.
  const handleUpdateEvent = useCallback((eventId, newDayKey, newHour) => {
    setEvents((prev) =>
      prev.map((event) =>
        String(event.id) === String(eventId)
          ? { ...event, dayKey: newDayKey, hour: newHour, time: `${newHour}:00` }
          : event
      )
    );
  }, []);

  return (
    <div className="app">
      <header className="app__header">
        <h1>Scheduled posts</h1>
      </header>

      {status === 'loading' && <p className="app__status">Loading events…</p>}
      {status === 'error' && (
        <p className="app__status app__status--error">Could not load scheduled posts. Try again shortly.</p>
      )}
      {status === 'ready' && (
        <Calendar weekDates={weekDates} events={events} onUpdateEvent={handleUpdateEvent} />
      )}
    </div>
  );
}

export default App;
