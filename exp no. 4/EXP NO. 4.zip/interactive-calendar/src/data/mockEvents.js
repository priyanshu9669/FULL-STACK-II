import { HOURS } from '../utils/dateUtils';

const TITLES = [
  'Instagram Reel',
  'Blog Post',
  'Newsletter',
  'Twitter Thread',
  'YouTube Short',
  'LinkedIn Article',
  'Podcast Episode',
  'Product Launch',
  'TikTok Clip',
  'Email Campaign',
];

const COLORS = ['#3f6c56', '#d1603d', '#c99a3e', '#5b6ea3', '#8c5a8c'];

/**
 * Generates deterministic mock "scheduled post" events spread across the
 * given week. Defaults to 60 events so the app's own data naturally
 * crosses the `processedData.length > 50` threshold that triggers the
 * lazily-loaded PremiumReportWidget (see Calendar.js).
 */
export function generateMockEvents(weekDates, count = 60) {
  const events = [];
  for (let i = 0; i < count; i += 1) {
    const day = weekDates[i % weekDates.length];
    const hour = HOURS[Math.floor(i / weekDates.length) % HOURS.length];
    events.push({
      id: String(i + 1),
      title: `${TITLES[i % TITLES.length]} #${i + 1}`,
      dayKey: day.key,
      hour,
      time: `${hour}:00`,
      color: COLORS[i % COLORS.length],
    });
  }
  return events;
}
