import { render, screen, waitFor } from '@testing-library/react';
import App from './App';

test('Assignment 5: loads scheduled posts from the mocked /api/events endpoint', async () => {
  render(<App />);

  expect(screen.getByText(/loading events/i)).toBeInTheDocument();

  await waitFor(() => {
    expect(screen.queryByText(/loading events/i)).not.toBeInTheDocument();
  });

  expect(screen.getByRole('grid', { name: /weekly scheduled posts/i })).toBeInTheDocument();
  // The mocked handler returns 60 events, so the lazily-loaded widget
  // (code-split via React.lazy + Suspense) should appear.
  expect(await screen.findByTestId('premium-widget')).toBeInTheDocument();
});
