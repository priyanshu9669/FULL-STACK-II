// Business-hours slots the calendar renders (8am - 7pm).
export const HOURS = Array.from({ length: 12 }, (_, i) => i + 8);

/**
 * Returns the Monday of the week containing `referenceDate`, at midnight.
 */
export function getStartOfWeek(referenceDate) {
  const day = referenceDate.getDay();
  const diffToMonday = (day === 0 ? -6 : 1) - day;
  const monday = new Date(referenceDate);
  monday.setDate(referenceDate.getDate() + diffToMonday);
  monday.setHours(0, 0, 0, 0);
  return monday;
}

/**
 * Builds the 7 days (Mon-Sun) for the week containing `referenceDate`.
 * Each entry has a stable `key` (YYYY-MM-DD) suitable for use as a React key
 * and for lookups - never an array index, per the reconciliation notes
 * in Experiment 4 (stable identity across inserts/removals/moves).
 */
export function getWeekDates(referenceDate) {
  const monday = getStartOfWeek(referenceDate);
  return Array.from({ length: 7 }, (_, i) => {
    const date = new Date(monday);
    date.setDate(monday.getDate() + i);
    return {
      date,
      key: formatDateKey(date),
      label: date.toLocaleDateString(undefined, { weekday: 'short', day: 'numeric' }),
    };
  });
}

export function formatDateKey(date) {
  return date.toISOString().slice(0, 10);
}
