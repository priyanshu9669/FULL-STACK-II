import { setupServer } from 'msw/node';
import { handlers } from './handlers';

// Used by src/setupTests.js so every test file gets a mocked
// /api/events without hitting a live backend.
export const server = setupServer(...handlers);
