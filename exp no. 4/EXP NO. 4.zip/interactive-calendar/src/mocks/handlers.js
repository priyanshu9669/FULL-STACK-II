import { rest } from 'msw';
import { generateMockEvents } from '../data/mockEvents';
import { getWeekDates } from '../utils/dateUtils';

export const handlers = [
  // Intercepts GET /api/events at the network layer and returns reliable
  // mock JSON, without needing a real backend or altering prod config.
  rest.get('/api/events', (req, res, ctx) => {
    const weekDates = getWeekDates(new Date());
    return res(ctx.status(200), ctx.json(generateMockEvents(weekDates, 60)));
  }),
];
