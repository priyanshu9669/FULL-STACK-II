import { setupWorker } from 'msw';
import { handlers } from './handlers';

// Used only in development (see src/index.js) so `npm start` works
// end-to-end against /api/events with zero backend setup.
export const worker = setupWorker(...handlers);
