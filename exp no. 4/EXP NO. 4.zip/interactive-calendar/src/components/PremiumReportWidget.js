import React, { useMemo } from 'react';

/**
 * Loaded via React.lazy + Suspense from Calendar.js only once there is
 * enough data to be worth the extra bundle weight (processedData.length
 * > 50). Keeping it in its own chunk means the initial page load never
 * pays for this component unless it will actually be shown.
 */
function PremiumReportWidget({ metrics }) {
  const countsByDay = useMemo(() => {
    const counts = {};
    metrics.forEach((m) => {
      counts[m.dayKey] = (counts[m.dayKey] || 0) + 1;
    });
    return counts;
  }, [metrics]);

  const max = Math.max(...Object.values(countsByDay), 1);

  return (
    <div className="premium-widget" data-testid="premium-widget">
      <h3>Weekly load</h3>
      <div className="premium-widget__bars">
        {Object.entries(countsByDay).map(([day, count]) => (
          <div key={day} className="premium-widget__bar-wrap">
            <div
              className="premium-widget__bar"
              style={{ height: `${(count / max) * 100}%` }}
              title={`${count} posts`}
            />
            <span className="premium-widget__bar-label">{day.slice(5)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default PremiumReportWidget;
