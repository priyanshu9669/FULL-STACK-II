import { render, screen, fireEvent } from '@testing-library/react';
import Calendar from './Calendar';
import { getWeekDates } from '../utils/dateUtils';

const weekDates = getWeekDates(new Date('2026-08-10T00:00:00'));

function makeDataTransfer(payload) {
  let stored = payload;
  return {
    setData: (_, value) => {
      stored = value;
    },
    getData: () => stored,
    dropEffect: 'move',
    effectAllowed: 'move',
  };
}

test('Assignment 2: dragging an event to a new slot updates its schedule', () => {
  const events = [
    { id: '1', title: 'Draft Post', dayKey: weekDates[0].key, hour: 8, time: '8:00', color: '#3f6c56' },
  ];
  const handleUpdateEvent = jest.fn();

  render(<Calendar weekDates={weekDates} events={events} onUpdateEvent={handleUpdateEvent} />);

  const card = screen.getByText('Draft Post');
  const targetSlot = screen.getByTestId(`slot-${weekDates[2].key}-11`);
  const dataTransfer = makeDataTransfer('1');

  fireEvent.dragStart(card, { dataTransfer });
  fireEvent.dragOver(targetSlot, { dataTransfer });
  fireEvent.drop(targetSlot, { dataTransfer });

  expect(handleUpdateEvent).toHaveBeenCalledWith('1', weekDates[2].key, 11);
});

test('Assignment 1: React.memo prevents EventCard from re-rendering for unrelated state changes', () => {
  const consoleSpy = jest.spyOn(console, 'log').mockImplementation(() => {});

  const events = [
    { id: '1', title: 'Newsletter Draft', dayKey: weekDates[0].key, hour: 8, time: '8:00', color: '#3f6c56' },
  ];

  const { rerender } = render(
    <Calendar weekDates={weekDates} events={events} onUpdateEvent={() => {}} />
  );

  const rendersAfterMount = consoleSpy.mock.calls.filter((call) => call[0] === 'Rendered:').length;
  expect(rendersAfterMount).toBe(1);

  // Re-render Calendar with a brand-new (but shallow-equal-content) events
  // array reference - simulates an unrelated parent re-render. Since the
  // event object itself is unchanged, EventCard's memo comparison should
  // still block a re-render for that card.
  rerender(<Calendar weekDates={weekDates} events={events} onUpdateEvent={() => {}} />);

  const rendersAfterRerender = consoleSpy.mock.calls.filter((call) => call[0] === 'Rendered:').length;
  expect(rendersAfterRerender).toBe(1);

  consoleSpy.mockRestore();
});

test('clicking an event filters the grid down to that event\'s day', () => {
  const events = [
    { id: '1', title: 'Monday Post', dayKey: weekDates[0].key, hour: 8, time: '8:00', color: '#3f6c56' },
    { id: '2', title: 'Tuesday Post', dayKey: weekDates[1].key, hour: 8, time: '8:00', color: '#d1603d' },
  ];

  render(<Calendar weekDates={weekDates} events={events} onUpdateEvent={() => {}} />);

  fireEvent.click(screen.getByText('Monday Post'));

  expect(screen.getByText('Monday Post')).toBeInTheDocument();
  expect(screen.queryByText('Tuesday Post')).not.toBeInTheDocument();
});

test('renders the premium report widget only once event volume passes 50', async () => {
  const fewEvents = [
    { id: '1', title: 'Only Post', dayKey: weekDates[0].key, hour: 8, time: '8:00', color: '#3f6c56' },
  ];
  const { rerender } = render(
    <Calendar weekDates={weekDates} events={fewEvents} onUpdateEvent={() => {}} />
  );
  expect(screen.queryByTestId('premium-widget')).not.toBeInTheDocument();

  const manyEvents = Array.from({ length: 60 }, (_, i) => ({
    id: String(i + 1),
    title: `Post #${i + 1}`,
    dayKey: weekDates[i % 7].key,
    hour: 8 + (i % 12),
    time: `${8 + (i % 12)}:00`,
    color: '#3f6c56',
  }));
  rerender(<Calendar weekDates={weekDates} events={manyEvents} onUpdateEvent={() => {}} />);

  expect(await screen.findByTestId('premium-widget')).toBeInTheDocument();
});
