import React, { useMemo, useState, useCallback, Suspense, lazy } from 'react';
import TimeSlot from './TimeSlot';
import { HOURS } from '../utils/dateUtils';

// Code-splitting via dynamic import: the analytics widget's bundle is only
// fetched when it's actually going to render, keeping the initial chunk light.
const PremiumReportWidget = lazy(() => import('./PremiumReportWidget'));

function Calendar({ weekDates, events, onUpdateEvent }) {
  const [selectedDayKey, setSelectedDayKey] = useState(null);

  // Recomputed only when `events` or `selectedDayKey` actually change -
  // caches the filtered list instead of re-filtering on every render
  // (e.g. when an unrelated ancestor state changes).
  const filteredEvents = useMemo(() => {
    if (!selectedDayKey) return events;
    return events.filter((event) => event.dayKey === selectedDayKey);
  }, [events, selectedDayKey]);

  // Bucket events by "day-hour" once per filteredEvents change, so each
  // TimeSlot can do a cheap object lookup instead of the grid re-filtering
  // the full event list 7 x 12 times per render.
  const eventsBySlot = useMemo(() => {
    const map = {};
    filteredEvents.forEach((event) => {
      const key = `${event.dayKey}-${event.hour}`;
      if (!map[key]) map[key] = [];
      map[key].push(event);
    });
    return map;
  }, [filteredEvents]);

  // useCallback keeps a stable function reference across renders so that
  // React.memo on TimeSlot / EventCard isn't defeated by a "new" callback
  // prop every time Calendar re-renders.
  const handleDrop = useCallback(
    (eventId, newDayKey, newHour) => {
      onUpdateEvent(eventId, newDayKey, newHour);
    },
    [onUpdateEvent]
  );

  const handleEventClick = useCallback((event) => {
    setSelectedDayKey((prev) => (prev === event.dayKey ? null : event.dayKey));
  }, []);

  return (
    <div className="calendar">
      <div className="calendar__grid" role="grid" aria-label="Weekly scheduled posts">
        <div className="calendar__corner" />
        {weekDates.map((day) => (
          <div key={day.key} className="calendar__day-header">
            {day.label}
          </div>
        ))}

        {HOURS.map((hour) => (
          <React.Fragment key={hour}>
            <div className="calendar__hour-label">{hour}:00</div>
            {weekDates.map((day) => (
              <TimeSlot
                // Stable unique key (day.key + hour), never an index -
                // keeps each cell's drag/drop listeners tied to the same
                // slot across re-renders and event moves.
                key={`${day.key}-${hour}`}
                dayKey={day.key}
                hour={hour}
                events={eventsBySlot[`${day.key}-${hour}`] || []}
                onDrop={handleDrop}
                onEventClick={handleEventClick}
              />
            ))}
          </React.Fragment>
        ))}
      </div>

      <Suspense fallback={<div className="calendar__loading">Loading premium interactive graphs...</div>}>
        {events.length > 50 && <PremiumReportWidget metrics={events} />}
      </Suspense>
    </div>
  );
}

// Memoize Calendar itself: if App re-renders for a reason that doesn't
// change weekDates/events/onUpdateEvent, this whole subtree is skipped.
export default React.memo(Calendar);
