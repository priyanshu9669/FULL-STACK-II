import React from 'react';

/**
 * EventCard is wrapped in React.memo so that, in a list of many scheduled
 * posts, a card only re-renders when its own `event` prop actually changes
 * (shallow comparison) - not whenever an unrelated sibling or ancestor
 * re-renders. This is the "list-based component" use case called out
 * under React Performance Optimization Techniques.
 */
const EventCard = React.memo(function EventCard({ event, onClick }) {
  // eslint-disable-next-line no-console
  console.log('Rendered:', event.title);

  const handleDragStart = (e) => {
    e.dataTransfer.setData('text/plain', event.id);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleClick = () => {
    if (onClick) onClick(event);
  };

  return (
    <div
      className="event-card"
      draggable
      onDragStart={handleDragStart}
      onClick={handleClick}
      style={{ borderLeftColor: event.color }}
      data-testid={`event-${event.id}`}
    >
      <span className="event-card__time">{event.time}</span>
      <span className="event-card__title">{event.title}</span>
    </div>
  );
});

export default EventCard;
