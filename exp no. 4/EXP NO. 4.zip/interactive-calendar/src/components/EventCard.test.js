import { render, screen } from '@testing-library/react';
import EventCard from './EventCard';

test('renders event title', () => {
  render(
    <EventCard
      event={{ id: '1', title: 'Meeting', time: '9:00', color: '#3f6c56' }}
      onClick={() => {}}
    />
  );
  expect(screen.getByText('Meeting')).toBeInTheDocument();
});

test('calls onClick with the event when clicked', async () => {
  const handleClick = jest.fn();
  render(
    <EventCard
      event={{ id: '2', title: 'Standup', time: '10:00', color: '#d1603d' }}
      onClick={handleClick}
    />
  );

  screen.getByText('Standup').click();
  expect(handleClick).toHaveBeenCalledWith(
    expect.objectContaining({ id: '2', title: 'Standup' })
  );
});
