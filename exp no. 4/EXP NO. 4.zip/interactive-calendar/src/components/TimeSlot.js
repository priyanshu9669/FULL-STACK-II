import React from 'react';
import EventCard from './EventCard';

/**
 * A single day/hour cell. Acts as the drop target: it accepts the dragged
 * event's id via the DataTransfer payload set in EventCard's onDragStart,
 * then hands the (eventId, dayKey, hour) triple up to the onDrop callback
 * so the calendar's state (owned by App) can be updated - mirroring the
 * onDrop(eventId, newDate) => updateEvent(...) pattern from the doc.
 */
const TimeSlot = React.memo(function TimeSlot({ dayKey, hour, events, onDrop, onEventClick }) {
  const handleDragOver = (e) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const handleDrop = (e) => {
    e.preventDefault();
    const eventId = e.dataTransfer.getData('text/plain');
    if (eventId) {
      onDrop(eventId, dayKey, hour);
    }
  };

  return (
    <div
      className="time-slot"
      onDragOver={handleDragOver}
      onDrop={handleDrop}
      data-testid={`slot-${dayKey}-${hour}`}
    >
      {events.map((event) => (
        // Stable, unique key (item.id) - not array index - so React can
        // track each card precisely as items move between slots.
        <EventCard key={event.id} event={event} onClick={onEventClick} />
      ))}
    </div>
  );
});

export default TimeSlot;
