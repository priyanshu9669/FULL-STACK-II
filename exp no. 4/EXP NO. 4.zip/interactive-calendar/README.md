# Interactive Calendar — Optimization & Testing

Implementation of **Unit 1, Experiment 4: Interactive Calendar Optimization & Testing**.
A calendar of scheduled posts that supports drag-and-drop rescheduling, is optimized
against unnecessary re-renders, and is backed by a full test suite with mocked APIs.

## Quick start

```bash
npm install
npm start          # runs at http://localhost:3000, backed by a mocked /api/events
npm test           # interactive watch mode
npm run test:coverage   # single run with a coverage report
```

No real backend is required — Mock Service Worker (MSW) intercepts
`GET /api/events` both in the browser (dev) and in Jest (tests) and returns
generated mock data, so `npm start` and `npm test` work immediately after
`npm install`.

## Project structure

```
src/
  App.js                       fetches events, owns state, wires drag-and-drop
  index.js / index.css         entry point + design tokens
  components/
    Calendar.js                grid, useMemo/useCallback, code-split widget
    TimeSlot.js                drop target for each day/hour cell
    EventCard.js                React.memo'd drag source, list item
    PremiumReportWidget.js     lazy-loaded analytics (React.lazy + Suspense)
    Calendar.test.js / EventCard.test.js
  utils/dateUtils.js           week/date helpers (stable date keys)
  data/mockEvents.js           deterministic mock event generator
  mocks/handlers.js            MSW request handlers for /api/events
  mocks/browser.js             MSW worker (dev)
  mocks/server.js              MSW server (tests)
  setupTests.js                jest-dom + MSW lifecycle
```

## How each assignment is covered

**Assignment 1 — Render Optimization**
`EventCard` is wrapped in `React.memo` and logs on every render so
unnecessary re-renders are observable. `Calendar` uses `useMemo` to cache
the filtered/bucketed event lists and `useCallback` to keep `onDrop` /
`onEventClick` referentially stable, so memoized children aren't
invalidated by an unrelated parent re-render. Every list (`TimeSlot`,
day headers, hour rows) is keyed by a stable id (`event.id`, `day.key`,
`hour`) — never an array index — per the reconciliation notes in the
experiment.

**Assignment 2 — Drag-and-Drop**
`EventCard` is the drag source (`draggable`, `onDragStart` sets the event
id on `DataTransfer`). `TimeSlot` is the drop target (`onDragOver`,
`onDrop`), and calls back up to `App`'s `handleUpdateEvent`, which updates
state immutably — mirroring the `onDrop(eventId, newDate) => updateEvent(...)`
pattern from the experiment.

**Assignment 3 — Profiling Analysis**
Run `npm start`, open React DevTools → Profiler, hit Record, drag an event
or click one to filter the grid, then Stop. The Flame Chart / Ranked Chart
will show `TimeSlot`/`EventCard` render times, and "Why did this render?"
will confirm the memoized cards are skipped when unrelated state changes.

**Assignment 4 — Component Testing**
`EventCard.test.js` renders a card and asserts on the rendered title/click
behavior with React Testing Library, testing behavior rather than
implementation, per the experiment's guidance.

**Assignment 5 — API Mocking + Coverage**
`mocks/handlers.js` intercepts `GET /api/events` with MSW and returns
generated mock data. `App.test.js` is an integration test that renders the
whole app against that mocked endpoint. `npm run test:coverage` reports
statement/branch/function/line coverage (thresholds set in `package.json`).

## Notes

- The mock API returns 60 events by default, which intentionally crosses
  the `processedData.length > 50` threshold so the code-split
  `PremiumReportWidget` (loaded via `React.lazy` + `Suspense`) renders out
  of the box — you can see its separate chunk load in the Network tab.
- All grid keys use stable identifiers (`event.id`, date keys, hour
  numbers) rather than array indices, avoiding the input-state/CSS-
  transition bugs described under "Key Selection Comparison Matrix".
